function MoreScreen() {
    return <h1>More</h1>;
}
export default MoreScreen;