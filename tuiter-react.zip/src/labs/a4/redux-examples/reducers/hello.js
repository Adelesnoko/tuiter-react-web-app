const hello = () => ({message: 'Hello World'});
export default hello;