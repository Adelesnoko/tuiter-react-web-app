function BookmarksScreen() {
    return <h1>Bookmarks</h1>;
}
export default BookmarksScreen;